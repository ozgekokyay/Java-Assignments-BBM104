
public class Main {

	public static void main(String[] args) {
		String command= args[0];

		CommandExecutor commandExecutor= new CommandExecutor(command);
		

	}

}
